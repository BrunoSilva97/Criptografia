from pwn import *
from binascii import hexlify, unhexlify

port = input()

r = remote("0.0.0.0",port)

print(r.recvline().decode())
print(r.recvline().decode())

r.sendline('0')

print(r.recvline().decode())
m = hexlify(b'Attack at dawn0!').decode()
print(m)
r.sendline(m)

print("Received ciphertext:")
rc = r.recvline().decode()
print(rc)

print("\n")

r.sendline('1')

print(r.recvline().decode())

r.sendline(hexlify(b'Attack at dawn0!').decode())
r.sendline(hexlify(b'Attack at dusk0!').decode())

print("Received ciphertext:")
rc2 = r.recvline().decode()
print(rc2)

print("\n")

r.sendline('2')

print(r.recvline().decode())

if (rc == rc2):
    print("I'll send 0")
    r.sendline('0')
else:
    print("I'll send 1")
    r.sendline('1')

print(r.recvline().decode())

r.close()
