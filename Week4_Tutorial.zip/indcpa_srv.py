from pwn import *
import random
import ciphersuite_aesctr as ciphersuite
from binascii import hexlify, unhexlify

def enc_oracle():
	l.sendline('Please submit your encryption query as a hex string: nonce in one line, message in next line')
	nonce = l.recvline(keepends=False)
	msg = l.recvline(keepends=False)
	try:
		cph = ciphersuite.enc(key,unhexlify(msg),unhexlify(nonce))
	except AssertionError:
		l.sendline("Incorrect ciphertext length")
		l.close()
		exit()
	l.sendline(hexlify(cph).decode())

def challenge():
	l.sendline('Please submit your two messages in three different lines: nonce in one line, messages in next lines')

	nonce = l.recvline(keepends=False)
	msg0 = l.recvline(keepends=False)
	msg1 = l.recvline(keepends=False)

	if (len(msg0) != len(msg1)):
		l.sendline("Messages must be of the same length!")
		l.close()
		exit()

	b = systemRandom.randint(0,1)

	if (b == 0):
		msg = msg0
	else:
		msg = msg1

	try:
		cph = ciphersuite.enc(key,unhexlify(msg),unhexlify(nonce))
	except AssertionError:
		l.sendline("Incorrect ciphertext length")
		l.close()
		exit()

	l.sendline(hexlify(cph).decode())
	return b


def guess(b):
	l.sendline('Submit your guess bit')

	b0 = int(l.recvline())

	if (b == b0):
		l.sendline("You got lucky!")
	else:
		l.sendline("Incorrect.")

systemRandom = random.SystemRandom()
port = systemRandom.randint(5000,9999)

l = listen(port)
l.wait_for_connection()

l.sendline("--- Welcome to the IND-CPA challenge. ---")
l.sendline("Select your mode of operation: 0 - Encryption oracle; 1 - Challenge query; 2 - Guess; 3 - Exit")
flag = 0
key = ciphersuite.gen()
 
while(1):
	mode = l.recvline()
	try:
		mode = int(mode)
	except: 
		l.close()
		exit()

	if mode == 0:
		enc_oracle()
	elif mode == 1:
		if (flag != 0):
			l.sendline("You can't repeat challenge queries")
		else:
			b = challenge()
			flag = 1
	elif mode == 2:
		guess(b)
		l.close()
		exit()
	elif mode == 3:
		l.close()
		exit()
	else:
		l.sendline("Invalid mode")

l.close()