from pwn import *
from binascii import hexlify, unhexlify

port = input()

r = remote("0.0.0.0",port)

print(r.recvline().decode())
print(r.recvline().decode())

r.sendline('0')
print(r.recvline().decode())

n = hexlify(b'Test nonce   13!').decode()
m = hexlify(b'Attack at dawn0!').decode()
print(n)
print(m)
r.sendline(n)
r.sendline(m)

print("Received ciphertext:")
r1 = r.recvline().decode()
print(r1)

print("\n")

r.sendline('1')
print(r.recvline().decode())

r.sendline(hexlify(b'Test nonce   13!').decode())
r.sendline(hexlify(b'Attack at dawn0!').decode())
r.sendline(hexlify(b'Attack at dusk0!').decode())

print("Received ciphertext:")
r2 = r.recvline().decode()
print(r2)

print("\n")

r.sendline('2')
print(r.recvline().decode())

if (r1 == r2):
    print("I'll try 0")
    r.sendline('0')
else:
    print("I'll try 1")
    r.sendline('1')

print(r.recvline().decode())

r.close()
