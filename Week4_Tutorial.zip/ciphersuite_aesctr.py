# Python Module ciphersuite
import os
import random
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# Security parameter (fixed)
KEYLEN = 16

# Use crypto random generation to get a key with up to 5 random bytes
def gen(): 
	return os.urandom(KEYLEN)

def enc(k, m, nonce):
	cipher = Cipher(algorithms.AES(k), modes.CTR(nonce))
	encryptor = cipher.encryptor()
	cph = b""
	cph += encryptor.update(m)
	cph += encryptor.finalize()
	return cph

def dec(k, c, nonce):
	cipher = Cipher(algorithms.AES(k), modes.CTR(nonce))
	decryptor = cipher.decryptor()
	msg = b""
	msg += decryptor.update(c)
	msg += decryptor.finalize()
	return msg
