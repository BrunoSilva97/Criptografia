import os

# Security parameter (fixed)
CPHLEN = 16
ideal_m = {}
ideal_c = {}

def enc(m):
	if m in ideal_m.keys():
		return ideal_m[m]
	cph = os.urandom(16)
	ideal_m[m] = cph
	ideal_c[cph] = m
	return cph

def dec(c):
	return (ideal_c[c].encode())