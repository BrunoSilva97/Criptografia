from pwn import *
from binascii import hexlify,unhexlify
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import itertools
import functools

def dec(k, c):
	cipher = Cipher(algorithms.AES(k), modes.ECB())
	decryptor = cipher.decryptor()
	msg = b""
	msg += decryptor.update(c)
	msg += decryptor.finalize()
	return msg

port = input()

r = remote("localhost", port)

print(r.recvline().decode())
print(r.recvline().decode())

r.sendline('0')

print(r.recvline().decode())

m = hexlify(b'Test message 12!').decode()
r.sendline(m)

# Encriptar texto
##[:-1] para tirar o \n do fim
cph = r.recvline()[:-1]
print("Received ciphertext:")
print(cph)
print("\n")

# Descobrir se foi encriptado com aesnotrand
res = '1'
offsetArray = list(itertools.product(['0', '1'], repeat=24))
for b in offsetArray:
	value = str("".join(b))
	valueHex = hex(int(value, 2))
	valueBytes = (('0'*32)+valueHex[2:])[-32:]
	key = unhexlify(valueBytes.encode())
	msg = dec(key, cph)
	try:
		if(msg.decode() == 'Test message 12!'):
			print("Descobri a chave!\n")
			res = '0'
			break
	except:
		continue


# Desncriptar texto
r.sendline('1')
print(r.recvline().decode()[:-1])
print("I'll try " + res)
r.sendline(res)

print(r.recvline().decode())

r.close()
