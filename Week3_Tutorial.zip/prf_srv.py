from pwn import *
import struct
import random
import ciphersuite_aesnotrand as ciphersuite
import ciphersuite_ideal
from binascii import hexlify,unhexlify


def enc_oracle():
	l.sendline('Please submit your encryption query')
	msg = l.recvline(keepends=False)
	if (b == 0):
		cph = ciphersuite.enc(key,unhexlify(msg))
	else:
		cph = ciphersuite_ideal.enc(unhexlify(msg))
	l.sendline(cph)


def test(b):
	l.sendline('Submit your guess bit')
	b0 = int(l.recvline().decode())
	if (b == b0):
		l.sendline("You got lucky!")
	else:
		l.sendline("Incorrect.")

systemRandom = random.SystemRandom()
port = systemRandom.randint(5000,9999)

l = listen(port)
l.wait_for_connection()

l.sendline("--- Welcome to the PRF challenge. ---")
l.sendline("Select your mode of operation: 0 - Encryption oracle; 1 - Test; 2 - Exit")
flag = 0
key = ciphersuite.gen()
b = systemRandom.randint(0,1)
while(1):
	mode = l.recvline()
	try:
		mode = int(mode)
	except:
		l.close()
		exit()

	if mode == 0:
		enc_oracle()
	elif mode == 1:
		test(b)
		l.close()
		exit()
	elif mode == 2:
		l.close()
		exit()
	else:
		l.sendline("Invalid mode")

l.close()
