from pwn import *
from cryptography.hazmat.primitives import hashes
import os

L = 5  # output length in bytes

# Something to make calling hash functions more succint
def H(X):
	digest = hashes.Hash(hashes.SHA256())
	digest.update(X)
	return (digest.finalize()[0:L])

# Write a function that finds the collision and presents the values in which it occurred
def floyd(h0):
	print("Hash is "+str(8*L)+" bits")

	i = 1
	h0 = H(h0)
	hi = H(H(h0))
	while (h0 != hi):
		h0 = H(h0)
		hi = H(H(hi))
		i += 1
	print(i)

	return (h0, hi)

start = os.urandom(L)
(h0, h1) = floyd(start)
print(h0)
print(h1)
